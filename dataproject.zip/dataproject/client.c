#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <locale.h>

#define SERVER_IP "127.0.0.1"  // Server IP (localhost for local testing)
#define PORT 8080
#define BUFFER_SIZE 1024
#define MAX_QUESTIONS 6  // Number of questions in the personal test

// Zodiac list
const char* zodiacList[] = {
    "1. Aries", "2. Taurus", "3. Gemini", "4. Cancer", 
    "5. Leo", "6. Virgo", "7. Libra", "8. Scorpio", 
    "9. Sagittarius", "10. Capricorn", "11. Aquarius", "12. Pisces"
};

void showZodiacList() {
    printf("Select your zodiac sign by number:\n");
    for (int i = 0; i < 12; i++) {
        printf("%s\n", zodiacList[i]);
    }
}

// Function for personalized test
int personalTest() {
    int totalPoints = 0;
    int answer;

    const char* questions[MAX_QUESTIONS] = {
        "I see myself as someone who can easily understand the emotions of others.",
        "When faced with challenges, I prefer to make rational decisions.",
        "Meeting new people and socializing gives me energy.",
        "I can focus on a specific task for a long time.",
        "I feel excited about trying new things.",
        "I generally enjoy taking risks and facing challenges."
    };

    // Asking questions and collecting responses
    for (int i = 0; i < MAX_QUESTIONS; i++) {
        printf("%s\n", questions[i]);
        printf("1: Strongly Disagree\n");
        printf("2: Disagree\n");
        printf("3: Neutral\n");
        printf("4: Agree\n");
        printf("5: Strongly Agree\n");

        // Get the user's answer
        printf("Your answer (1-5): ");
        scanf("%d", &answer);

        // Ensure the answer is valid (between 1 and 5)
        if (answer >= 1 && answer <= 5) {
            totalPoints += answer;
        } else {
            printf("Invalid input. Please enter a number between 1 and 5.\n");
            i--;  // Retry the question
        }
    }

    return totalPoints;
}

int main() {
    setlocale(LC_ALL, "Turkish");

    WSADATA wsaData;
    SOCKET client_socket;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE] = {0};
    char birthDate[20];
    int zodiacNumber;

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed. Error Code: %d\n", WSAGetLastError());
        return 1;
    }

    // Create socket
    if ((client_socket = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        printf("Socket creation failed. Error Code: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);
    server_addr.sin_port = htons(PORT);

    // Connect to the server
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        printf("Connection failed. Error Code: %d\n", WSAGetLastError());
        closesocket(client_socket);
        WSACleanup();
        return 1;
    }

    printf("Connected to the server!\n");

    // Show zodiac list and get user input
    showZodiacList();
    printf("Enter the number of your zodiac sign (1-12): ");
    scanf("%d", &zodiacNumber);

    // Validate zodiac number
    if (zodiacNumber < 1 || zodiacNumber > 12) {
        printf("Invalid selection! Please restart and choose a number between 1 and 12.\n");
        closesocket(client_socket);
        WSACleanup();
        return 1;
    }

    // Get birth date
    printf("Enter your birth date (YYYYMMDD): ");
    scanf("%s", birthDate);

    // Perform the personalized test
    printf("Answer the following questions for a personalized test:\n");
    int testPoints = personalTest();

    // Combine all data into one message
    snprintf(buffer, BUFFER_SIZE, "%s %s %d", zodiacList[zodiacNumber - 1] + 3, birthDate, testPoints);

    // Send data to the server
    send(client_socket, buffer, strlen(buffer), 0);

    // Clear the buffer for receiving server response
    memset(buffer, 0, BUFFER_SIZE);

    // Receive response from the server
    int valread = recv(client_socket, buffer, BUFFER_SIZE - 1, 0);
    if (valread > 0) {
        buffer[valread] = '\0';  // Null-terminate the received string
        printf("Response from server:\n%s\n", buffer);
    } else {
        printf("Failed to receive response from the server.\n");
    }

    // Close socket
    closesocket(client_socket);
    WSACleanup();
    getchar();
    getchar();

    return 0;
}
