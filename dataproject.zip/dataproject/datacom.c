
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <locale.h>
#include <pthread.h>  // For multithreading
#define MAX_QUESTIONS 6  // Number of questions in the personal test

#define PORT 8080
#define BUFFER_SIZE 1024
#define MAX_ZODIAC 12
#define MAX_COMMENT 256

// Struct for zodiac signs and their comments
struct ZodiacComment {
    char zodiacName[20];
    char comment[MAX_COMMENT];
};

// Function to calculate numerology from a birth date
int calculateNumerology(const char* birthDate) {
    int sum = 0;
    // Sum all digits
    for (int i = 0; i < strlen(birthDate); i++) {
        if (birthDate[i] >= '0' && birthDate[i] <= '9') {
            sum += birthDate[i] - '0';
        }
    }
    // Reduce to a single digit
    while (sum >= 10) {
        int temp = 0;
        while (sum > 0) {
            temp += sum % 10;
            sum /= 10;
        }
        sum = temp;
    }
    return sum;
}

// Function to get numerology meaning
const char* getNumerologyMeaning(int number) {
    const char* meanings[] = {
        "1: Leadership and independence.",
        "2: Balance and partnership.",
        "3: Creativity and joy.",
        "4: Stability and discipline.",
        "5: Adventure and freedom.",
        "6: Responsibility and care.",
        "7: Spirituality and wisdom.",
        "8: Ambition and power.",
        "9: Compassion and universal love."
    };
    return meanings[number - 1];
}


// Function to get the personalized test result
const char* getPersonalizedTestResult(int totalPoints) {
    if (totalPoints >= 5 && totalPoints <= 10) {
        return "You may have an introverted and analytical personality.";
    } else if (totalPoints >= 11 && totalPoints <= 15) {
        return "You have a balanced and harmonious personality.";
    } else if (totalPoints >= 16 && totalPoints <= 20) {
        return "You might be social and outgoing.";
    } else if (totalPoints >= 21 && totalPoints <= 25) {
        return "You are energetic, creative, and adventurous.";
    } else {
        return "Invalid input.";
    }
}

// Function to perform the personal test
void personalTest() {
    int totalPoints = 0;
    int answer;

    // Questions for the personal test
    const char* questions[MAX_QUESTIONS] = {
        "I see myself as someone who can easily understand the emotions of others.",
        "When faced with challenges, I prefer to make rational decisions.",
        "Meeting new people and socializing gives me energy.",
        "I can focus on a specific task for a long time.",
        "I feel excited about trying new things.",
        "I generally enjoy taking risks and facing challenges."
    };

    // Asking questions and collecting responses
    for (int i = 0; i < MAX_QUESTIONS; i++) {
        printf("%s\n", questions[i]);
        printf("1: Strongly Disagree\n");
        printf("2: Disagree\n");
        printf("3: Neutral\n");
        printf("4: Agree\n");
        printf("5: Strongly Agree\n");
        
        // Getting the user's answer
        printf("Your answer (1-5): ");
        scanf("%d", &answer);
        
        // Ensure the answer is valid (between 1 and 5)
        if (answer >= 1 && answer <= 5) {
            totalPoints += answer;
        } else {
            printf("Invalid input. Please enter a number between 1 and 5.\n");
            i--;  // Retry the question
        }
    }

    // Print the result of the personal test
    printf("\nTest Result:\n");
    const char* result = getPersonalizedTestResult(totalPoints);
    printf("%s\n", result);
}



// ***Function to handle each client
void* handleClient(void* socket_desc) {
    SOCKET client_socket = *(SOCKET*)socket_desc;
    char buffer[BUFFER_SIZE] = {0};
    char response[BUFFER_SIZE] = "Zodiac not found!";

    // Receive and process data
    int valread = recv(client_socket, buffer, BUFFER_SIZE - 1, 0);
    if (valread > 0) {
        buffer[valread] = '\0';  // Null-terminate the received string
        printf("Received data: %s\n", buffer);

        // Parse zodiac and birth date
        char zodiacName[20];
        char birthDate[20];
        sscanf(buffer, "%s %s", zodiacName, birthDate);

        // Define zodiac signs and comments
        struct ZodiacComment zodiacs[MAX_ZODIAC] = {
            {"Aries", "You are energetic and enthusiastic today. A great day for new beginnings."},
            {"Taurus", "Be patient; great opportunities await you."},
            {"Gemini", "Use your communication skills to achieve significant success."},
            {"Cancer", "You may have a strong emotional day."},
            {"Leo", "Be confident; your leadership skills will shine."},
            {"Virgo", "Pay attention to details to complete your tasks successfully."},
            {"Libra", "You will strive to maintain balance today."},
            {"Scorpio", "Your passion and determination will overcome challenges."},
            {"Sagittarius", "You may embark on new adventures with your free spirit."},
            {"Capricorn", "Your hard work and discipline will be appreciated."},
            {"Aquarius", "Your creative ideas will influence those around you."},
            {"Pisces", "Use your imagination to achieve excellent results."}
        };

        // Find zodiac comment
        for (int i = 0; i < MAX_ZODIAC; i++) {
            if (strcmp(zodiacName, zodiacs[i].zodiacName) == 0) {
                strcpy(response, zodiacs[i].comment);
                break;
            }
        }

        // Calculate numerology
        int numerology = calculateNumerology(birthDate);
        const char* numerologyMeaning = getNumerologyMeaning(numerology);

        // Append numerology result to response
        char numerologyResult[BUFFER_SIZE];
        snprintf(numerologyResult, BUFFER_SIZE, "\nNumerology Result: %d - %s", numerology, numerologyMeaning);
        strcat(response, numerologyResult);

        // Send response
        send(client_socket, response, strlen(response), 0);
        printf("Response sent: %s\n", response);
    } else {
        printf("Failed to receive data from client.\n");
    }

    // Close the client socket
    closesocket(client_socket);
    free(socket_desc);
    return NULL;
}

int main() {
    setlocale(LC_ALL, "Turkish");

    WSADATA wsaData;
    SOCKET server_fd, client_socket;
    struct sockaddr_in server_addr, client_addr;
    int client_len = sizeof(client_addr);

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed. Error Code: %d\n", WSAGetLastError());
        return 1;
    }

    // Create server socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        printf("Socket creation failed. Error Code: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    // Configure address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind socket
    if (bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        printf("Bind failed. Error Code: %d\n", WSAGetLastError());
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    // Start listening
    if (listen(server_fd, 3) == SOCKET_ERROR) {
        printf("Listen failed. Error Code: %d\n", WSAGetLastError());
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    printf("Server is listening... Port: %d\n", PORT);

    // Accept multiple clients
    while (1) {
        client_socket = accept(server_fd, (struct sockaddr*)&client_addr, &client_len);
        if (client_socket == INVALID_SOCKET) {
            printf("Connection accept failed. Error Code: %d\n", WSAGetLastError());
            continue;
        }

        printf("A client connected!\n");

        // Create a new thread to handle the client
        pthread_t client_thread;
        SOCKET* new_sock = malloc(sizeof(SOCKET));
        *new_sock = client_socket;

        if (pthread_create(&client_thread, NULL, handleClient, (void*)new_sock) < 0) {
            printf("Could not create thread.\n");
            free(new_sock);
            closesocket(client_socket);
        }

        // Detach the thread so that resources are automatically cleaned up after the client is done
        pthread_detach(client_thread);
    }

    // Close the server socket
    closesocket(server_fd);
    WSACleanup();
    getchar();
    return 0;
}
