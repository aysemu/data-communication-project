#include <iostream>
#include <stdio.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <string.h>
#include <thread>
#include <bitset>
#include <vector>

using namespace std;
char id;
std::vector<std::bitset<9>> parity_values;

std::bitset<9> parityCheck(std::bitset<8> binary)
{
    std::bitset<9> parity_binary;
    int count = 0;

    // İlk 8 biti kopyala
    for (int i = 0; i < 8; ++i)
    {
        parity_binary[i] = binary[i];
        if (binary[i])
        {
            ++count;
        }
    }

    // Parity bitini ekle
    parity_binary[8] = count % 2;

    return parity_binary;
}

// İki boyutlu parity check fonksiyonu
std::vector<std::bitset<9>> twoDimensionalParityCheck(std::vector<std::bitset<9>> parity_values)
{
    std::bitset<9> parity_row;
    int count;

    // Her sütun için parity bitini hesapla
    for (int i = 0; i < 9; ++i)
    {
        count = 0;
        for (const auto &parity_binary : parity_values)
        {
            if (parity_binary[i])
            {
                ++count;
            }
        }
        parity_row[i] = count % 2;
    }

    // Parity satırını ekle
    parity_values.push_back(parity_row);

    return parity_values;
}

void rcvmess(SOCKET socket)
{
    int recv_len;
    char message[400];
    memset(message, 0, sizeof(message));

    printf("\nsize mesaj yollanmasi bekleniyor\n");

    if (recv_len = recv(socket, message, sizeof(message), 0) == SOCKET_ERROR)
    {
    }
    else
    {

        printf("size %c tarafindan yollanan mesaj:\n", message[0]);
        puts(message);
        parity_values = twoDimensionalParityCheck(parity_values);

        std::cout << "Parity değerler dizisi: ";
        for (const auto &parity_binary : parity_values)
        {
            std::cout << parity_binary << ' ';
        }

        printf("sizin cevabiniz(mesajlasmayi durdurmak icin  dur   yazin):\n");
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        memset(message, 0, sizeof(message));
        message[0] = id;
        cin.getline(message + 1, 399);

        if (strcmp(message, "dur") == 0)
            closesocket(socket);

        send(socket, message, sizeof(message), 0);
        printf("\nmesajiniz gönderildi\n");
    }
}
void sendmess(SOCKET socket)
{
    char message[400];

    printf("\nmesahi yollamak istediğiniz clientin idsi ve mesaji bitisik olarak giriniz\n");

    memset(message, 0, sizeof(message));

    char mess[100];
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    std::string mesaj;
    std::cout << "Bir mesaj girin: ";
    std::getline(std::cin, mesaj);

    std::vector<std::bitset<9>> parity_values;

    for (char c : mesaj)
    {
        std::bitset<8> binary(c);
        std::bitset<9> parity_binary = parityCheck(binary);
        parity_values.push_back(parity_binary);
        std::cout << "Karakter: '" << c << "', ASCII: " << int(c) << ", Binary: " << binary << ", Parity: " << parity_binary << std::endl;
    }

    send(socket, message, strlen(message), 0);

    if (strcmp(message, "dur") == 0)
        closesocket(socket);

    puts("mesaj yollandi\n");

    memset(message, 0, sizeof(message));

    recv(socket, message, sizeof(message), 0);

    printf("%c idli clientin yolladigi mesaj:", message[0]);
    puts(message);

    printf("mesajinizi giriniz bu konusmayi bitirmek isterseniz  dur  yaziniz");
}

int main(int argc, char *argv[])
{
    WSADATA wsa;
    SOCKET s;
    struct sockaddr_in server;

    int recv_size;
    char message[405];
    // message[0]='1';

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    // Create a socket
    if ((s = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
    {
        printf("Could not create socket : %d", WSAGetLastError());
    }

    printf("Socket created.\n");

    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(8080);

    if (connect(s, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        puts("connect error");
        return 1;
    }

    puts("Connected");

    printf("bilgilerinizi giriniz");
    printf("\n ilk önce id numarasi olacak sekilde isim yaziniz örn(1ahmet)");

    cin.getline(message, 400);

    id = message[0];

    send(s, message, sizeof(message), 0);

    printf("client listesi\n");

    recv(s, message, sizeof(message), 0);
    puts(message);

    int k;

    while (true)
    {
        printf("mesaj yollamak mi yoksa idle beklemek mi istiyorsunuz\n");
        printf("mesaj yollamak icin 1 idle beklemek icin 2 giriniz\n");
        cin >> k;
        if (k == 1)
        {
            //  std::thread(sendmess,s).detach();
            sendmess(s);
        }
        else if (k == 2)
        {
            rcvmess(s);
            //  std::thread(rcvmess,s).detach();
        }
    }

    getchar();

    return 0;
}
