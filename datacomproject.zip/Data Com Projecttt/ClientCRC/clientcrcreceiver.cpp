#include <iostream>
#include <stdio.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <string.h>
#include <thread>
#include <bitset>

using namespace std;
char id;
WSADATA wsa;
SOCKET s;
struct sockaddr_in server;

string xor1(string a, string b)
{

    string result = "";

    int n = b.length();

    for (int i = 1; i < n; i++)
    {
        if (a[i] == b[i])
            result += "0";
        else
            result += "1";
    }
    return result;
}

string mod2div(string dividend, string divisor)
{

    string anhtr = "1101";

    int pick = divisor.length();

    string tmp = dividend.substr(0, pick);

    int n = dividend.length();

    while (pick < n)
    {
        if (tmp[0] == '1')

            tmp = xor1(divisor, tmp) + dividend[pick];
        else

            tmp = xor1(std::string(pick, '0'), tmp) + dividend[pick];

        pick += 1;
    }

    if (tmp[0] == '1')
        tmp = xor1(divisor, tmp);
    else
        tmp = xor1(std::string(pick, '0'), tmp);

    return tmp;
}

void encodeDataAndSend_CRC(string veri)
{

    string anhtr = "1101";

    int l_key = anhtr.length();

    // Appends n-1 zeroes at end of veri
    string appended_data = (veri + std::string(l_key - 1, '0'));

    string kalan = mod2div(appended_data, anhtr);

    

    string codeword = veri + kalan;

    send(s, codeword.c_str(), strlen(codeword.c_str()), 0);
}

bool receiveMessageCRC(string veri)
{

    string anhtr = "1101";

    veri+=mod2div(veri + std::string(anhtr.size() - 1, '0'),anhtr);

    string suanxor = mod2div(veri.substr(0, anhtr.size()), anhtr);
    int suan = anhtr.size();
    while (suan != veri.size())
    {
        if (suanxor.size() != anhtr.size())
        {
            suanxor.push_back(veri[suan++]);
        }
        else
        {
            suanxor = mod2div(suanxor, anhtr);
        }
    }
    if (suanxor.size() == anhtr.size())
    {
        suanxor = mod2div(suanxor, anhtr);
    }
    if (suanxor.find('1') != string::npos)
    {
      //  cout << "there is some error in veri" << endl;
      return false;
    }
    else
    {
      //  cout << "correct message received" << endl;
      return true;
    }
}



int main(int argc, char *argv[])
{
    int recv_size;
    char message[405];
    // message[0]='1';

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    // Create a socket
    if ((s = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
    {
        printf("Could not create socket : %d", WSAGetLastError());
    }

    printf("Socket created.\n");

    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(8080);

    if (connect(s, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        puts("connect error");
        return 1;
    }

    puts("Connected");

    printf("bilgilerinizi giriniz");
    printf("\n ilk önce id numarasi olacak sekilde isim yaziniz örn(1ahmet)");

    cin.getline(message, 400);

    char messagetemp[500];

    messagetemp[0]='r';

    strcpy(messagetemp+1,message);
    strcpy(message,messagetemp);

    send(s, message, sizeof(message), 0);

    printf("client listesi\n");

    recv(s, message, sizeof(message), 0);
    puts(message);

    recv(s,message,sizeof(message),0);

    int k;
   // memset(message, 0, sizeof(message));
    char original_message[400];
    
    while (true)
    {
        int result=recv(s,message,sizeof(message),0);

        if(result==SOCKET_ERROR)
        {
            continue;
        }
        else if(result==0)
        {
            break;
        }
        else
        {
            puts(message);
        }


    }
    
    recv(s,message,sizeof(message),0);
    puts(message);
 
    getchar();

    return 0;
}
