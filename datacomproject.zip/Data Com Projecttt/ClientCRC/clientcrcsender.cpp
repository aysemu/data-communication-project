#include <iostream>
#include <stdio.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <string.h>
#include <thread>
#include <bitset>

using namespace std;
char id;
WSADATA wsa;
SOCKET s;
struct sockaddr_in server;

string xor1(string a, string b)
{

    string result = "";

    int n = b.length();

    for (int i = 1; i < n; i++)
    {
        if (a[i] == b[i])
            result += "0";
        else
            result += "1";
    }
    return result;
}

string mod2div(string dividend, string divisor)
{

    string anhtr = "1101";

    int pick = divisor.length();

    string tmp = dividend.substr(0, pick);

    int n = dividend.length();

    while (pick < n)
    {
        if (tmp[0] == '1')

            tmp = xor1(divisor, tmp) + dividend[pick];
        else

            tmp = xor1(std::string(pick, '0'), tmp) + dividend[pick];

        pick += 1;
    }

    if (tmp[0] == '1')
        tmp = xor1(divisor, tmp);
    else
        tmp = xor1(std::string(pick, '0'), tmp);

    return tmp;
}

void encodeDataAndSend_CRC(string veri)
{

    string anhtr = "1101";

    int l_key = anhtr.length();

    // Appends n-1 zeroes at end of veri
    string appended_data = (veri + std::string(l_key - 1, '0'));

    string kalan = mod2div(appended_data, anhtr);

    

    string codeword = veri + kalan;

    send(s, codeword.c_str(), strlen(codeword.c_str()), 0);
}

bool receiveMessageCRC(string veri)
{

    string anhtr = "1101";

    veri+=mod2div(veri + std::string(anhtr.size() - 1, '0'),anhtr);

    string suanxor = mod2div(veri.substr(0, anhtr.size()), anhtr);
    int suan = anhtr.size();
    while (suan != veri.size())
    {
        if (suanxor.size() != anhtr.size())
        {
            suanxor.push_back(veri[suan++]);
        }
        else
        {
            suanxor = mod2div(suanxor, anhtr);
        }
    }
    if (suanxor.size() == anhtr.size())
    {
        suanxor = mod2div(suanxor, anhtr);
    }
    if (suanxor.find('1') != string::npos)
    {
      //  cout << "there is some error in veri" << endl;
      return false;
    }
    else
    {
      //  cout << "correct message received" << endl;
      return true;
    }
}

void rcvmess(SOCKET socket)
{
    int recv_len;
    char message[400];
    // string anhtr = "1101";
    memset(message, 0, sizeof(message));

    printf("\nsize mesaj yollanmasi bekleniyor\n");

    if (recv_len = recv(socket, message, sizeof(message), 0) == SOCKET_ERROR)
    {
    }
    else
    {

        printf("size %c tarafindan yollanan mesaj:\n", message[0]);
       
          receiveMessageCRC(message);
       // receive(message + mod2div(message + std::string(anhtr.size() - 1, '0'), anhtr), anhtr);

        printf("sizin cevabiniz(mesajlasmayi durdurmak icin  dur   yazin):\n");
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        memset(message, 0, sizeof(message));
        message[0] = id;
        cin.getline(message + 1, 399);

        if (strcmp(message, "dur") == 0)
            closesocket(socket);

        send(socket, message, sizeof(message), 0);
        printf("\nmesajiniz gönderildi\n");
    }
}
void sendmess(SOCKET socket)
{
    char message[400];
    string veri, anhtr = "1101";

    printf("\nmesahi yollamak istediğiniz clientin idsi ve mesaji bitisik olarak giriniz\n");

    memset(message, 0, sizeof(message));

    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    cin.getline(message, 100);
    for (char c : message)
    {
        veri += bitset<8>(c).to_string();
    }
    cout << veri;
    encodeDataAndSend_CRC(veri);

    if (strcmp(message, "dur") == 0)
        closesocket(socket);

    puts("mesaj yollandi\n");

    memset(message, 0, sizeof(message));

    recv(socket, message, sizeof(message), 0);

    printf("%c idli clientin yolladigi mesaj:", message[0]);
    puts(message);

    printf("mesajinizi giriniz bu konusmayi bitirmek isterseniz  dur  yaziniz");
}

int main(int argc, char *argv[])
{
    int recv_size;
    char message[405];
    // message[0]='1';

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    // Create a socket
    if ((s = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
    {
        printf("Could not create socket : %d", WSAGetLastError());
    }

    printf("Socket created.\n");

    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(8080);

    if (connect(s, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        puts("connect error");
        return 1;
    }

    puts("Connected");

    printf("bilgilerinizi giriniz");
    printf("\n ilk önce id numarasi olacak sekilde isim yaziniz örn(1ahmet)");

    cin.getline(message, 400);

    // id = message[0];

    char messagetemp[500];

    // messagetemp[0]=message[0];

    messagetemp[0]='s';

    strcpy(messagetemp+1,message);
    strcpy(message,messagetemp);

   // printf("%s\n\n",message);   
   // printf("%s\n\n",messagetemp);   


    send(s, message, sizeof(message), 0);

    printf("client listesi\n");

    recv(s, message, sizeof(message), 0);
    puts(message);

    int k;

    printf("bitisik olacak sekilde mesaji yollayacaginiz idyi ve mesaji giriniz\n");
    
    // cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    memset(message, 0, sizeof(message));

    cin.getline(message,400);

    

    send(s,message,sizeof(message),0);

    encodeDataAndSend_CRC(message);

    getchar();

    return 0;
}
