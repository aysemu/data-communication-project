#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <list>
#include <thread>
#include <cstring>

using namespace std;

int client_id_counter;
class clients
{public:

    int id;
    string isim;
    SOCKET client_socket;
    char type;
    
};
 struct sockaddr_in clientAddr;
 int addrLen;
 std::list<clients> clientliste;

 
void corruptmess(SOCKET socket, char buf[500])
{

    if(buf[1]-'0'%2==0)
    {
        buf[1]='1';
    }
    else
    {
        buf[1]='0';
    }
    send(socket,buf,500,0);

}

void HandleClient(SOCKET clientSocket) {
    
    char original_message[500];


    int c;
    char buf[512];
    std::list<clients>::iterator it;
    clients temp;
    int currentIndex = 0;
    char client_listesi[500] ;



   recv(clientSocket, buf, 512, 0);
    

    clients client_temp;
    client_temp.id=client_id_counter;
    client_id_counter++;
    client_temp.isim=buf+1;
    client_temp.type=buf[0];
    client_temp.client_socket=clientSocket;





    bool listede_varmi =false;

    if(!clientliste.empty())
    {
        for (it = clientliste.begin(); it != clientliste.end(); ++it) 
            {  
                if(it->id==client_temp.id)
                listede_varmi=true;
            }
    }        



    if(listede_varmi==false)
    {
        clientliste.push_back(client_temp);

    }
    else
    {
        closesocket(clientSocket);
    }

    for (it = clientliste.begin(); it != clientliste.end(); ++it) 
    {
        if(it->client_socket==clientSocket)
        temp.id=it->id;
        addrLen = sizeof(clientAddr);
        getpeername(it->client_socket, (struct sockaddr*)&clientAddr, &addrLen);

        // sockaddr_in tipindeki adres bilgisini daha önceki gibi kullanabilirsin
        int writtenChars = snprintf(client_listesi + currentIndex, sizeof(client_listesi) - currentIndex, 
            "Client ID: %d, Name: %s, Type: %c, IP: %s, Port: %d\n", 
            it->id, it->isim.c_str(), it->type, inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));


        if (writtenChars < 0 || currentIndex + writtenChars >= sizeof(client_listesi)) 
        {
            std::cerr << "Hata: char dizisi sınırlarını aşıyor." << std::endl;
            break;
        }
        currentIndex += writtenChars;
    }


    send(clientSocket,client_listesi,sizeof(client_listesi),0);
    
    memset(buf,0,sizeof(buf));

    

    while(true)
    {
        if(client_temp.type=='s')
        {

            recv(clientSocket,buf,sizeof(buf),0);

            char hedef=buf[0];    
        
            char a;
        
            a = static_cast<char>('0'+client_temp.id);

            for (it = clientliste.begin(); it != clientliste.end(); ++it) 
            {
                if(it->id==hedef-'0' )
                {
                    char buftemp[500];
                
                    strcpy(buftemp+1, buf + 1);
                
                    buftemp[0]=a;

                    strcpy(buf,buftemp);

                    FILE *file;
                    file=fopen("mesaj.log", "a+");

                    fprintf(file,"%s\n",buf);
                    fclose(file);

                // corruptmess(it->client_socket,buf);

                // recv(it->client_socket,buftemp,sizeof(buftemp),0);

                    send(it->client_socket,buf,sizeof(buf),0);

                }
            
            }
        
        }
    }

}



int main()
{
    client_id_counter=1;

    std::list<clients>::iterator it;

    WSADATA wsaData;
    SOCKET s, new_socket;
    struct sockaddr_in server, client;
    int c, recv_len;
    char buf[512];

    printf("Initialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    if ((s = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
    {
        printf("Could not create socket : %d", WSAGetLastError());
        return 1;
    }
 
    printf("Socket created.\n");

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_port = htons(8080);

   
    if (bind(s, (struct sockaddr *)&server, sizeof(server)) == SOCKET_ERROR)
    {
        printf("Bind failed with error code : %d", WSAGetLastError());
        return 1;
    }

    puts("Bind done");

    listen(s, 3);

    puts("Listening...");

    while (true)
    {
    
    
        c = sizeof(struct sockaddr_in);
        new_socket=accept(s, (struct sockaddr *)&client, &c );
        
        for (it = clientliste.begin(); it != clientliste.end(); ++it) 
        {
        if(it->client_socket==new_socket)
        continue;
     
        }

        
        if (new_socket == INVALID_SOCKET)
        {
            printf("accept failed with error code : %d\n", WSAGetLastError());
            // break;
        }
        printf("Connection accepted.\n");

        printf("Waiting for data...\n\n");


        std::thread(HandleClient, new_socket).detach();
        

    
    }

    getchar();
    closesocket(s);
    WSACleanup();

    return 0;
}