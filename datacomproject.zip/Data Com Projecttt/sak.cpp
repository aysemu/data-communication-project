#include <iostream>
#include <bitset>
#include <vector>
//#include <string>

// Parity check fonksiyonu
std::bitset<9> parityCheck(std::bitset<8> binary) {
    std::bitset<9> parity_binary;
    int count = 0;

    // İlk 8 biti kopyala
    for (int i = 0; i < 8; ++i) {
        parity_binary[i] = binary[i];
        if (binary[i]) {
            ++count;
        }
    }

    // Parity bitini ekle
    parity_binary[8] = count % 2;

    return parity_binary;
}

// İki boyutlu parity check fonksiyonu
std::vector<std::bitset<9>> twoDimensionalParityCheck(std::vector<std::bitset<9>> parity_values) {
    std::bitset<9> parity_row;
    int count;

    // Her sütun için parity bitini hesapla
    for (int i = 0; i < 9; ++i) {
        count = 0;
        for (const auto& parity_binary : parity_values) {
            if (parity_binary[i]) {
                ++count;
            }
        }
        parity_row[i] = count % 2;
    }

    // Parity satırını ekle
    parity_values.push_back(parity_row);

    return parity_values;
    




}

int main() {
    std::string mesaj;
    std::cout << "Bir mesaj girin: ";
    std::getline(std::cin, mesaj);

    std::vector<std::bitset<9>> parity_values;

    for (char c : mesaj) {
        std::bitset<8> binary(c);
        std::bitset<9> parity_binary = parityCheck(binary);
        parity_values.push_back(parity_binary);
        std::cout << "Karakter: '" << c << "', ASCII: " << int(c) << ", Binary: " << binary << ", Parity: " << parity_binary << std::endl;
    }

    // İki boyutlu parity check ekleyin
    parity_values = twoDimensionalParityCheck(parity_values);

    std::cout << "Parity değerler dizisi: ";
    for (const auto& parity_binary : parity_values) {
        std::cout << parity_binary << ' ';
    }

    return 0;
}
