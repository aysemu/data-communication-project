#include <iostream>
#include <stdio.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <string.h>
#include <thread>
#include <bitset>
#include <vector>

using namespace std;
char id;
WSADATA wsa;
SOCKET s;
struct sockaddr_in server;



// Parity check fonksiyonu
std::bitset<9> parityCheck(std::bitset<8> binary) {
    std::bitset<9> parity_binary;
    int count = 0;

    // İlk 8 biti kopyala
    for (int i = 0; i < 8; ++i) {
        parity_binary[i] = binary[i];
        if (binary[i]) {
            ++count;
        }
    }

    // Parity bitini ekle
    parity_binary[8] = count % 2;

    return parity_binary;
}

// İki boyutlu parity check fonksiyonu
std::vector<std::bitset<9>> twoDimensionalParityCheck(std::vector<std::bitset<9>> parity_values) {
    std::bitset<9> parity_row;
    int count;

    // Her sütun için parity bitini hesapla
    for (int i = 0; i < 9; ++i) {
        count = 0;
        for (const auto& parity_binary : parity_values) {
            if (parity_binary[i]) {
                ++count;
            }
        }
        parity_row[i] = count % 2;
    }

    // Parity satırını ekle
    parity_values.push_back(parity_row);

    return parity_values;
}

// Mesajı parametre olarak alan ve two dimensional parity check yapan fonksiyon
std::vector<std::bitset<9>> processMessage(const std::string& mesaj) {
    std::vector<std::bitset<9>> parity_values;

    for (char c : mesaj) {
        std::bitset<8> binary(c);
        std::bitset<9> parity_binary = parityCheck(binary);
        parity_values.push_back(parity_binary);
        std::cout << "Karakter: '" << c << "', ASCII: " << int(c) << ", Binary: " << binary << ", Parity: " << parity_binary << std::endl;
    }

    // İki boyutlu parity check ekleyin
    parity_values = twoDimensionalParityCheck(parity_values);

    std::cout << "Parity değerler dizisi: ";
    for (const auto& parity_binary : parity_values) {
        std::cout << parity_binary << ' ';
    }

    return parity_values;
}

// Parity değerlerini parametre olarak alan ve orijinal mesajı çözen fonksiyon
std::string decryptMessage(const std::vector<std::bitset<9>>& parity_values)
{
    std::string message;

    // Son satırı (parity satırı) atla
    for (int i = 0; i < parity_values.size() - 1; ++i)
    {
        std::bitset<8> binary;
        for (int j = 0; j < 8; ++j)
        {
            binary[j] = parity_values[i][j];
        }
        char c = static_cast<char>(binary.to_ulong());
        message += c;
    }

    return message;
}

//crc


string xor1(string a, string b)
{

    string result = "";

    int n = b.length();

    for (int i = 1; i < n; i++)
    {
        if (a[i] == b[i])
            result += "0";
        else
            result += "1";
    }
    return result;
}

string mod2div(string dividend, string divisor)
{

    string anhtr = "1101";

    int pick = divisor.length();

    string tmp = dividend.substr(0, pick);

    int n = dividend.length();

    while (pick < n)
    {
        if (tmp[0] == '1')

            tmp = xor1(divisor, tmp) + dividend[pick];
        else

            tmp = xor1(std::string(pick, '0'), tmp) + dividend[pick];

        pick += 1;
    }

    if (tmp[0] == '1')
        tmp = xor1(divisor, tmp);
    else
        tmp = xor1(std::string(pick, '0'), tmp);

    return tmp;
}

void encodeDataAndSend_CRC(SOCKET s,string veri)
{


    string anhtr = "1101";

    int l_key = anhtr.length();

    // Appends n-1 zeroes at end of veri
    string appended_data = (veri + std::string(l_key - 1, '0'));

    string kalan = mod2div(appended_data, anhtr);

    

    string codeword = veri + kalan;

    send(s, codeword.c_str(), strlen(codeword.c_str()), 0);
}

bool receiveMessageCRC(string veri)
{

    string anhtr = "1101";

    veri+=mod2div(veri + std::string(anhtr.size() - 1, '0'),anhtr);

    string suanxor = mod2div(veri.substr(0, anhtr.size()), anhtr);
    int suan = anhtr.size();
    while (suan != veri.size())
    {
        if (suanxor.size() != anhtr.size())
        {
            suanxor.push_back(veri[suan++]);
        }
        else
        {
            suanxor = mod2div(suanxor, anhtr);
        }
    }
    if (suanxor.size() == anhtr.size())
    {
        suanxor = mod2div(suanxor, anhtr);
    }
    if (suanxor.find('1') != string::npos)
    {
      //  cout << "there is some error in veri" << endl;
      return false;
    }
    else
    {
      //  cout << "correct message received" << endl;
      return true;
    }
}

int main(int argc, char *argv[])
{
    int recv_size;
    char message[405];
    

    printf("\nInitialising Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }

    printf("Initialised.\n");

    // Create a socket
    if ((s = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
    {
        printf("Could not create socket : %d", WSAGetLastError());
    }

    printf("Socket created.\n");

    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(8080);

    if (connect(s, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        puts("connect error");
        return 1;
    }

    puts("Connected");

    printf("\nisminizi yaziniz\n");
    cin.getline(message, 400);

    // id = message[0];

    char messagetemp[500];

    // messagetemp[0]=message[0];

    messagetemp[0]='s';

    strcpy(messagetemp+1,message);
    strcpy(message,messagetemp);

   // printf("%s\n\n",message);   
   // printf("%s\n\n",messagetemp);   


    send(s, message, sizeof(message), 0);

    printf("client listesi\n");

    recv(s, message, sizeof(message), 0);
    puts(message);

    int k;

    while(true)
    {
        printf("bitisik olacak sekilde mesaji yollayacaginiz idyi ve mesaji giriniz\n");
    
        // cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        memset(message, 0, sizeof(message));

        cin.getline(message,400);

    

        send(s,message,sizeof(message),0);

    // encodeDataAndSend_CRC(s,message);
    }

    getchar();

    return 0;
}
