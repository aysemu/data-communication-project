#include <iostream>
#include <string>
#include <bitset>
using namespace std;

string xor1(string a, string b)
{

    string result = "";

    int n = b.length();

    for (int i = 1; i < n; i++)
    {
        if (a[i] == b[i])
            result += "0";
        else
            result += "1";
    }
    return result;
}

string mod2div(string dividend, string divisor)
{

    int pick = divisor.length();

    string tmp = dividend.substr(0, pick);

    int n = dividend.length();

    while (pick < n)
    {
        if (tmp[0] == '1')

            tmp = xor1(divisor, tmp) + dividend[pick];
        else

            tmp = xor1(std::string(pick, '0'), tmp) + dividend[pick];

        pick += 1;
    }

    if (tmp[0] == '1')
        tmp = xor1(divisor, tmp);
    else
        tmp = xor1(std::string(pick, '0'), tmp);

    return tmp;
}

void encodeData(string veri, string anhtr)
{
    int l_key = anhtr.length();

    // Appends n-1 zeroes at end of veri
    string appended_data = (veri + std::string(l_key - 1, '0'));

    string kalan = mod2div(appended_data, anhtr);

    string codeword = veri + kalan;
    cout << "Kalan : " << kalan << "\n";
    cout << "Sifrelenmis veri (veri + kalan) :" << codeword
         << "\n";
}

void receiver(string veri, string anhtr)
{
    string suanxor = mod2div(veri.substr(0, anhtr.size()), anhtr);
    int suan = anhtr.size();
    while (suan != veri.size())
    {
        if (suanxor.size() != anhtr.size())
        {
            suanxor.push_back(veri[suan++]);
        }
        else
        {
            suanxor = mod2div(suanxor, anhtr);
        }
    }
    if (suanxor.size() == anhtr.size())
    {
        suanxor = mod2div(suanxor, anhtr);
    }
    if (suanxor.find('1') != string::npos)
    {
        cout << "there is some error in veri" << endl;
    }
    else
    {
        cout << "correct message received" << endl;
    }
}

int main()
{
    string veri, mes;
    cout << "Enter message : ";
    cin >> mes;

    for (char c : mes)
    {
        veri += bitset<8>(c).to_string();
    }
    cout << veri << endl;

    string anhtr = "1101";
    cout << "Sender side..." << endl;
    encodeData(veri, anhtr);

    cout << "\nReceiver side..." << endl;
    receiver(veri + mod2div(veri + std::string(anhtr.size() - 1, '0'), anhtr), anhtr);
    cin >> mes;

    return 0;
}
